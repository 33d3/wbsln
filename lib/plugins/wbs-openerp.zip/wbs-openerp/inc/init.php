<?php

if(is_admin())
	include 'admin/wbs_open_admin.php';
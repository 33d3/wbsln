<?php

function websolns_openerp_create_menu() {

	//create new top-level menu
	add_submenu_page(
		'websolns-settings-page', 
		__('OpenERP',LANGUAGE_ZONE),  
		__('OpenERP',LANGUAGE_ZONE), 
		'administrator', 
		'wbsopenerp-settings-page', 
		'openerp_settings_page',
		get_stylesheet_directory_uri().'/img/wbsadminlogo.png'
	);
}

// create custom plugin settings menu
add_action('admin_menu', 'websolns_openerp_create_menu');


function openerp_settings_page() {
?>
<div class="wrap" id="wbs_open_admin_options">
	<h2><?php _e('OpenErp Options',LANGUAGE_ZONE) ?></h2>
	<hr/>
	
	<h2 class="nav-tab-wrapper">
			<a data-id="options-group-0" class="nav-tab buttons-tab nav-tab-active" title="Front Options" href="#">General Options</a>
			<a data-id="options-group-1" class="nav-tab buttons-tab" title="Business Info" href="#">Business Info</a>
	</h2>

	<div id="options-group-0" class="group active">
			<?php include 'inc/general_options.php';?>
	</div>	
	<div id="options-group-1" class="group">
		here
	</div>
</div>
<style scoped>
#wbs_open_admin_options > .group:not(:first-of-type){
	display:none;
}
</style>
<script>

jQuery(document).ready(function($){
    
    $('#wbs_open_admin_options > .nav-tab-wrapper a').click(function(e){
        e.preventDefault();
        var item = $(this).data('id'); 
        $('#wbs_open_admin_options > .nav-tab-wrapper > .nav-tab-active').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        $('#wbs_open_admin_options > .group.active')
            .removeClass('active')
            .fadeOut('normal',function(){
                $('#'+item).addClass('active').fadeIn('normal');    
            });
    });
});

</script>
<?php } ?>
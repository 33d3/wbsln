<?php 

include 'openerp-con/OpenERP.php';

function getRedirectsToUri($uri)
{
	$redirects = array();
	$http = stream_context_create();
	stream_context_set_params(
	$http,
	array(
	"notification" => function() use (&$redirects)
	{
		if (func_get_arg(0) === STREAM_NOTIFY_REDIRECTED) {
			$redirects[] = func_get_arg(2);
		}
	}
	)
	);
	file_get_contents($uri, false, $http);
	return $redirects;
}

$user = 'admin';
$password = 'Se91133442!';
$dbname = 'erpwebsolns';
$server_url = getRedirectsToUri("http://crmweb.no-ip.org")[0];

$erp = new OpenERP($server_url, 'utf-8');
$erp->login($dbname, $user, $password);
$readColumns = ['name', 'email', 'role'];
$ids = $erp->search('res.partner',[['customer', '=', '1']]);

$partners = $erp->read('res.partner', $ids);

foreach ($partners as $p):
$p = (OBJECT)$p;
if(!$p->is_company)
	continue;
?>
<div class="client_box">
	<div class="client_box_inner">
		<?php 
			if($p->image_small)
				$image = 'data:text/html;charset=utf-8;base64,'.$p->image_small;
			else
				$image = plugins_url().'/wbs-openerp/inc/admin/img/avatar.png';
		?>
		<img src="<?php echo $image?>">
		<div class="client_box_text">
			<b><?php echo $p->name?></b>
			<ul>
				<li><?php echo is_array($p->contact_address)?'':$p->contact_address?></li> 
				<li><?php echo $p->website?$p->website:'' ?></li>                                      
			</ul>
		</div>
	</div>
</div>
<?php endforeach;?>
<style scoped>
.client_box{
	display: inline-block !important;
	padding: 2px;
	vertical-align: top;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
	position: relative;
	display: block;
	min-height: 20px;
	margin: 0;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	border-radius: 4px;
}

.client_box_inner{
	min-height: 80px;
}	

.client_box_inner img{
	display: inline-block;
	vertical-align: top;
	width: 64px;
	height: 64px;
	text-align: center;
	overflow: hidden;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	-moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.4);
	-webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.4);
	-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.4);
}

.client_box_text{
	display: inline-block;
	vertical-align: top;
	width: 240px;
	font-size: 13px;
	padding: 0 5px;
	color: #4c4c4c;
}

.client_box_inner ul, .client_box_inner li{
	margin:0;
}
</style>
<?php
/*
 Plugin Name: WBS OpenErp
Description: Connect OpenErp with Wordpress
Version: 1.0
Author: Emrah Ede
Author URI: http://emrahede.com
*/

add_action('init', function(){
	include 'inc/init.php';
});